package projetobdepoo;
/**
 * @author Mari,Pedrinho e Re
 */
public class ProjetoBDePOO 
{
    public static void main(String[] args) 
    {
       TelaInicial ti = new TelaInicial();
       ti.setVisible(true);
    }
    
}
