package projetobdepoo;

public class Pessoa 
{    
    
    
    private String nome;
    private String sobrenome;
   // private static int contador=0;
////////////////////////////////////////////////////////////////////////////////
    private String email;
    private String senha;
////////////////////////////////////////////////////////////////////////////////
    private String rua;
    private int num;
    private String complemento;
    private String bairro;
    private String cep;
    private String cidade;
    private String estado;
    private int qtd_moradores;   
////////////////////////////////////////////////////////////////////////////////
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }   
////////////////////////////////////////////////////////////////////////////////
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
////////////////////////////////////////////////////////////////////////////////
    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getQtd_moradores() {
        return qtd_moradores;
    }

    public void setQtd_moradores(int qtd_moradores) {
        this.qtd_moradores = qtd_moradores;
    }    
}
