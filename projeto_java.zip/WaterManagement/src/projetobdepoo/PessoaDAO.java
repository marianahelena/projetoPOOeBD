package projetobdepoo;

import java.sql.SQLException;

public class PessoaDAO extends ConexaoBD
{    
    // CADASTRAR
     public boolean cadastrarUsuario(Pessoa novoUsuario) 
     {
        super.connectToDb(); //Conecta ao banco de dados
        //Comando SQL para inserir dados
        String sqlP = "INSERT INTO pessoa(email,senha,nome,sobrenome,rua,num,complemento"
                +",bairro,cep,nome_cidade,uf_estado_cidade,qtd_moradores) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
        try 
        {
            //Inserir dados na tabela Pessoa 
            super.pst = super.con.prepareStatement(sqlP);
            //login
            super.pst.setString(1, novoUsuario.getEmail()); //1- refere-se à primeira interrogação
            super.pst.setString(2, novoUsuario.getSenha()); //2- refere-se à segunda interrogação
            //usuário                                             e assim por diante....
            super.pst.setString(3, novoUsuario.getNome());  
            super.pst.setString(4, novoUsuario.getSobrenome());
            //endereço
            super.pst.setString(5, novoUsuario.getRua());
            super.pst.setInt(6, novoUsuario.getNum());
            super.pst.setString(7, novoUsuario.getComplemento());
            super.pst.setString(8, novoUsuario.getBairro());
            super.pst.setString(9, novoUsuario.getCep());
            super.pst.setString(10, novoUsuario.getCidade());
            super.pst.setString(11, novoUsuario.getEstado());
            super.pst.setInt(12, novoUsuario.getQtd_moradores());
            //executa o comando
            super.pst.execute();
            //se deu tudo certo, então atualiza a variável sucesso p/ true
            super.sucesso = true;
        } 
        catch (SQLException ex) 
        {   //erro na interação com o SQL, então atualiza a variável sucesso p/ false
            super.sucesso = false;
            System.out.println(ex.getMessage()); //mostra erro ocorrido
        } 
        finally 
        {
            try 
            {   //Encerra a conexão
                super.con.close();
                super.pst.close();
            } 
            catch (SQLException ex) 
            {   //erro no momento de finalizar a conexão 
                System.out.println(ex.getMessage());
            }
        }
        return super.sucesso;
    }

    // ATUALIZAR ENDEREÇO
     public boolean atualizarEndereco(Pessoa usuario) 
     {
        super.connectToDb(); //Conecta ao banco de dados
        //Comando SQL para atualizar dados
       String sql = "UPDATE pessoa SET rua=?,num=?,complemento=?,bairro=?,"
              + "cep=?,nome_cidade=?,uf_estado_cidade=?,qtd_moradores=? WHERE email=?";
        try {
            super.pst = super.con.prepareStatement(sql);
            super.pst.setString(1, usuario.getRua() );
            super.pst.setInt(2, usuario.getNum());
            super.pst.setString(3, usuario.getComplemento() );
            super.pst.setString(4, usuario.getBairro() );
            super.pst.setString(5, usuario.getCep() );
            super.pst.setString(6, usuario.getCidade() );
            super.pst.setString(7, usuario.getEstado() );
            super.pst.setInt(8, usuario.getQtd_moradores());
            super.pst.setString(9, usuario.getEmail());
            super.pst.execute(); //executa o comando SQL
            super.sucesso = true;
        } catch (SQLException ex) { //erro na interação com o BD
            super.sucesso = false;
            System.out.println(ex.getMessage());
        } finally {
            try { //encerra conexão
                con.close();
                pst.close();
            } catch (SQLException ex) { //erro na interação com o BD
                System.out.println(ex.getMessage());
            }

        }
        return super.sucesso;
     }
     
     public boolean deletarUsuario(Pessoa usuario) {
        super.connectToDb(); //Conecta ao banco de dados
        //Comando SQL para deletar 
        String sql = "DELETE FROM pessoa WHERE email=?";
        try {
            super.pst = super.con.prepareStatement(sql);
            super.pst.setString(1,usuario.getEmail());
            super.pst.execute();
            super.sucesso = true;
        } catch (SQLException ex) {
            super.sucesso = false;
            System.out.println(ex.getMessage());
        } finally {
            try {
                super.con.close();
                super.pst.close();
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
        return super.sucesso;
    }
    
     //VERIFICAR EXISTÊNCIA DO LOGIN DENTRO DO BANCO DE DADOS
     public boolean buscarLogin(String user_email, String user_senha) 
     {
        boolean achou=false;
        //Conecta ao banco de dados
        super.connectToDb();
        /*Comando SQL para buscar:  seleciona a senha que está armazenada na tabela pessoa 
    onde o campo email corresponder a um determinado valor)*/
        String sql = "SELECT senha FROM pessoa WHERE email = ?";
        String aux;
        try {
            //Como o email a ser consultado não é fixo, realizaremos uma consulta dinâmica.
            //Portanto, usaremos o objeto pst.
            super.pst = super.con.prepareStatement(sql);
            pst.setString(1, user_email);
            super.rs = super.pst.executeQuery(); //Executa a consulta SQL e retorna um objeto gerado pela consulta
            while(rs.next()) //rs.next-> retorna false se não houver mais nenhuma linha a ser processada.
            {
                aux=rs.getString("senha"); 
                if(aux.isEmpty()) //Se não há uma senha, então o email não foi encontrado no sistema!
                {
                    achou = false;
                    //System.out.println("email errado");
                }
                else if(!aux.equals(user_senha)) //Se a senha digitada pelo usuário estiver errada:
                {
                    achou = false;
                    //System.out.println("senha errada");
                }
                else achou=true;
            }
            //super.sucesso = true; //variável que verifica sucesso das operações no banco de dados
        } catch (SQLException ex) { //Erro na interação com o BD
            System.out.println(ex.getMessage());
            //super.sucesso = false;
        } finally {
            try {
                //Encerra conexão
                super.con.close();
                super.pst.close();
            } catch (SQLException ex) { //Erro na interação com o BD
                System.out.println(ex.getMessage());
            }
        }
        return achou;
    }
     
     //BUSCAR PESSOA
     public Pessoa buscarPessoa(String user_email) 
     {
         Pessoa usuario = new Pessoa();
         usuario.setEmail(user_email);
         //Conecta ao banco de dados
        super.connectToDb();
        //Comando SQL para buscar
        String sql = "SELECT * FROM pessoa WHERE email=?";
        try 
        {
            //Como o email a ser consultado não é fixo, realizaremos uma consulta dinâmica.
            super.pst = super.con.prepareStatement(sql);
            pst.setString(1, user_email);
            super.rs = super.pst.executeQuery(); //Executa a consulta SQL e retorna um objeto gerado pela consulta
            while(rs.next()) //rs.next->retorna false se não houver mais nenhuma linha a ser processada.
            {
                //Pegando as informações guardadas no Banco de Dados referente a Pessoa
                usuario.setNome(rs.getString("nome"));
                usuario.setSobrenome(rs.getString("sobrenome"));
                usuario.setSenha(rs.getString("senha"));
                usuario.setRua(rs.getString("rua"));
                usuario.setNum(rs.getInt("num"));
                usuario.setBairro(rs.getString("bairro"));
                usuario.setCep(rs.getString("cep"));
                usuario.setCidade(rs.getString("nome_cidade"));
                usuario.setEstado(rs.getString("uf_estado_cidade"));
                usuario.setQtd_moradores(rs.getInt("qtd_moradores"));
            }
            //super.sucesso = true; //variável que verifica sucesso das operações no banco de dados
        } catch (SQLException ex) {//Erro na interação com o BD
            System.out.println(ex.getMessage());
            //super.sucesso = false;
        } finally {
            try {//Encerra conexão
                super.con.close();
                super.pst.close();
            } catch (SQLException ex) {//Erro na interação com o BD
                System.out.println(ex.getMessage());
            }
        }
        //return sucesso;
        return usuario;
    }
}

