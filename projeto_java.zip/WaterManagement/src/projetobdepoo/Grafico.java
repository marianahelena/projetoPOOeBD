package projetobdepoo;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Random;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

public class Grafico 
{
    private DefaultCategoryDataset dataset;
    private ArrayList<Integer> gastos;
    private Random randomGenerator = new Random();
    private int numAleatorio;
    
    public Grafico() 
    {
        dataset = new DefaultCategoryDataset();
        gastos = new ArrayList<>();
    }
    
    public int add()
    {
        for (int i = 0; i <= 12; i++) 
        {
            numAleatorio = randomGenerator.nextInt(5000)+1;
            gastos.add(numAleatorio);
        }
        dataset.addValue(gastos.get(0),"Consumo mensal","Jan.");
        dataset.addValue(gastos.get(1),"Consumo mensal","Fev.");
        dataset.addValue(gastos.get(2),"Consumo mensal","Mar.");
        dataset.addValue(gastos.get(3),"Consumo mensal","Abr.");
        dataset.addValue(gastos.get(4),"Consumo mensal","Maio.");
        dataset.addValue(gastos.get(5),"Consumo mensal","Jun.");
        dataset.addValue(gastos.get(6),"Consumo mensal","Jul.");
        dataset.addValue(gastos.get(7),"Consumo mensal","Ago.");
        dataset.addValue(gastos.get(8),"Consumo mensal","Set.");
        dataset.addValue(gastos.get(9),"Consumo mensal","Out.");
        dataset.addValue(gastos.get(10),"Consumo mensal","Nov.");
        dataset.addValue(gastos.get(11),"Consumo mensal","Dez.");
        return gastos.get(11);
    }
    
    public void geraGrafico()
    {
         
        JFreeChart criaGrafico = ChartFactory.createLineChart("Consumo mensal em litros",
                "", "",dataset,PlotOrientation.VERTICAL,true, true,false);
        try{
           // System.out.println("Criando o grafico...");
            OutputStream png = new FileOutputStream("GraficoDeConsumo.png");
            ChartUtilities.writeChartAsPNG(png, criaGrafico, 500, 400);
            png.close();
        }catch(IOException io){
            //System.out.println("Erro: "+ io.getMessage());
        }
    }
    
}
