package projetobdepoo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public abstract class ConexaoBD 
{
     // objeto responsável pela conexão com o servidor do banco de dados
    Connection con;
    // objeto responsável por preparar as consultas dinâmicas
    PreparedStatement pst;
    // objeto responsável por executar as consultas estáticas
    Statement st;
    // objeto responsável por referenciar a tabela resultante da busca
    ResultSet rs;

    // NOME DO BANCO DE DADOS
    String database = "mydb";
    // URL: VERIFICAR QUAL A PORTA
    String url = "jdbc:mysql://localhost:3306/" + database + "?useTimezone=true&serverTimezone=UTC&useSSL=false";
    // USUÁRIO
    String user = "root";
    // SENHA
    String password = "root";

    boolean sucesso = false;

    // Conectar ao banco de dados
    public void connectToDb() 
    {
        try {
            con = DriverManager.getConnection(url, user, password);  
                //System.out.println("Conexão feita com sucesso!");

        } catch (SQLException ex) {
               // System.out.println("Erro: " + ex.getMessage());

        }
    }
}
